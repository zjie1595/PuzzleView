package com.xiaopo.flying.photolayout;

/**
 * @author wupanjie
 */

public interface Callback {
  void onSuccess();

  void onFailed();
}
